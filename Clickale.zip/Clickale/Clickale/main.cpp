#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace sf;

class crosshair {
private:
    Texture crosshairTexture;
    Sprite crosshairSprite;

public:
    crosshair() {
        crosshairTexture.loadFromFile("crosshair.png");
        crosshairSprite.setTexture(crosshairTexture);
        crosshairSprite.setScale(0.5, 0.5);
    };
    void setPosition(float x, float y) {
        crosshairSprite.setPosition(x, y);
    }
    void dibujar(RenderWindow& nombreVentana) {

        nombreVentana.draw(crosshairSprite);

    }

    FloatRect getGlobalBounds() {
        return crosshairSprite.getGlobalBounds();
    }

};

class enemigo {
private:
    Texture etTexture;
    Sprite etSprite;

public:
    enemigo() {
        etTexture.loadFromFile("et.png");
        etSprite.setTexture(etTexture);
        etSprite.setScale(0.06F, 0.06F);
    }
    void setPosition(float x, float y) {
        etSprite.setPosition(x, y);
    }
    void dibujar(RenderWindow& nombreVentana) {

        nombreVentana.draw(etSprite);
    }
    FloatRect getGlobalBounds() {
        return etSprite.getGlobalBounds();
    }
};

class game {
private:
    RenderWindow App;
    crosshair playerCrosshair;
    enemigo et;
    int puntos;

public:
    game() : App(VideoMode(800, 600, 32), "Clickale") {
        App.setMouseCursorVisible(false);
        puntos = 0;
        generarPosicionAleatoria();
        playerCrosshairEstaSobreEt();
    }
    void generarPosicionAleatoria() {
        // Generar una posici�n aleatoria para "et" dentro de los l�mites de la ventana
        int x = std::rand() % 651 + 100;
        int y = std::rand() % 550 + 50;
        et.setPosition(x, y);
    }
    bool playerCrosshairEstaSobreEt() {
        FloatRect etBounds = et.getGlobalBounds();
        FloatRect crosshairBounds = playerCrosshair.getGlobalBounds();
        return etBounds.intersects(crosshairBounds);
    }

    void run() {
        while (App.isOpen()) {
            procesarEventos();
            actualizar();
            dibujar();
            condicionCorte();
        }
    }

    void condicionCorte() {
        if (puntos == 5) {
            App.close();
        }
    }

    void procesarEventos() {
        Event evt;
        while (App.pollEvent(evt)) {
            switch (evt.type) {
            case Event::Closed:
                App.close();
                break;
            case Event::MouseMoved:
                playerCrosshair.setPosition((float)evt.mouseMove.x, (float)evt.mouseMove.y);
                break;
            case Event::MouseButtonPressed:
                if (evt.mouseButton.button == Mouse::Left) {
                    // Comprobar si el "playerCrosshair" est� sobre el "et"
                    if (playerCrosshairEstaSobreEt()) {
                        // Incrementar el contador de puntos
                        puntos++;
                        // Generar una nueva posici�n aleatoria para "et"
                        generarPosicionAleatoria();
                    }
                }
                break;
            }
        }
    }

    void actualizar() {
    
    }

    void dibujar() {
        App.clear();
        et.dibujar(App);
        playerCrosshair.dibujar(App);
        App.display();
    }

};



int main() {
    std::srand(std::time(NULL));

    game myGame;
    myGame.run();
    return 0;
}
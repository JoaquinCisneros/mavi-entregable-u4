//////Bibliotecas//////
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
using namespace sf;

//////Variables//////
Texture texture_a;
Texture texture_b;
Texture texture_c;
Texture texture_d;
Texture punto_azul_t;
Sprite punto_azul;
Sprite sprite_a;
Sprite sprite_b;
Sprite sprite_c;
Sprite sprite_d;

bool isDragging = false; // Variable para verificar si se est� arrastrando un objeto
Sprite* selectedSprite = nullptr; // Puntero al objeto seleccionado

///Punto de entrada a la aplicaci�n///
int main() {
    //Cargamos la textura del archivo
    texture_a.loadFromFile("rcircle.png");
    texture_b.loadFromFile("rcircle.png");
    texture_c.loadFromFile("rcircle.png");
    texture_d.loadFromFile("rcircle.png");
    punto_azul_t.loadFromFile("PuntoAzul.png");

    //Cargamos el material del sprite
    sprite_a.setTexture(texture_a);
    sprite_b.setTexture(texture_b);
    sprite_c.setTexture(texture_c);
    sprite_d.setTexture(texture_d);
    punto_azul.setTexture(punto_azul_t);

    //Movemos los Sprites
    sprite_b.setPosition(675, 0);
    sprite_c.setPosition(0, 475);
    sprite_d.setPosition(675, 475);
    punto_azul.setPosition(300, 200);

    //Creamos la ventana
    sf::RenderWindow App(sf::VideoMode(800, 600, 32), "Sniper");

    // Loop principal
    while (App.isOpen()) {
        Event evt;
        while (App.pollEvent(evt)) {
            switch (evt.type) {
            case Event::Closed:
                App.close();
                break;

            case Event::MouseButtonPressed:
                // Verificar si se hizo clic en un objeto
                if (evt.mouseButton.button == Mouse::Left) {
                    if (sprite_a.getGlobalBounds().contains(evt.mouseButton.x, evt.mouseButton.y)) {
                        isDragging = true;
                        selectedSprite = &sprite_a;
                    }
                    else if (sprite_b.getGlobalBounds().contains(evt.mouseButton.x, evt.mouseButton.y)) {
                        isDragging = true;
                        selectedSprite = &sprite_b;
                    }
                    else if (sprite_c.getGlobalBounds().contains(evt.mouseButton.x, evt.mouseButton.y)) {
                        isDragging = true;
                        selectedSprite = &sprite_c;
                    }
                    else if (sprite_d.getGlobalBounds().contains(evt.mouseButton.x, evt.mouseButton.y)) {
                        isDragging = true;
                        selectedSprite = &sprite_d;
                    }
                    else if (punto_azul.getGlobalBounds().contains(evt.mouseButton.x, evt.mouseButton.y)) {
                        isDragging = true;
                        selectedSprite = &punto_azul;
                    }
                }
                break;

            case Event::MouseButtonReleased:
                // Dejar de arrastrar cuando se suelta el bot�n del mouse
                if (evt.mouseButton.button == Mouse::Left) {
                    isDragging = false;
                    selectedSprite = nullptr;
                }
                break;

            case Event::MouseMoved:
                // Arrastrar el objeto seleccionado
                if (isDragging && selectedSprite != nullptr) {
                    selectedSprite->setPosition(evt.mouseMove.x, evt.mouseMove.y);
                }
                break;
            }
        }

        // Limpiamos la ventana
        App.clear();

        // Dibujamos la escena
        App.draw(sprite_a);
        App.draw(sprite_b);
        App.draw(sprite_c);
        App.draw(sprite_d);
        App.draw(punto_azul);

        // Mostramos la ventana
        App.display();
    }

    return 0;
}



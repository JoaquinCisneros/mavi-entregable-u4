#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

using namespace sf;

int main() {
    RenderWindow App(VideoMode(800, 600, 32), "Ventana fea");

    const Vector2u minWindowSize(100, 100);
    const Vector2u maxWindowSize(1000, 1000);

    while (App.isOpen()) {
        Event evt;
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed) {
                App.close();
            }
            else if (evt.type == Event::Resized) {
                Vector2u newSize = App.getSize();

                // Limitar el tama�o de la ventana al m�nimo y m�ximo
                newSize.x = std::max(newSize.x, minWindowSize.x);
                newSize.y = std::max(newSize.y, minWindowSize.y);
                newSize.x = std::min(newSize.x, maxWindowSize.x);
                newSize.y = std::min(newSize.y, maxWindowSize.y);

                // Establecer el tama�o de la ventana seg�n las restricciones
                App.setSize(newSize);
            }
        }
        App.clear();
        App.display();
    }

    return 0;
}

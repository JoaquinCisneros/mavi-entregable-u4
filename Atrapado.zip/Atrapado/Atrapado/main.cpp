#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

using namespace sf;

class Game : RenderWindow {
public:
    Game() : RenderWindow (VideoMode(800, 600), "Ventana fea") {
        cuadAmarilloTexture.loadFromFile("cuad_yellow.png");
        cuadAmarillo.setTexture(cuadAmarilloTexture);
        cuadAmarillo.setPosition(100, 100);

        rcircleTexture.loadFromFile("rcircle.png");
        rcircle.setTexture(rcircleTexture);
        rcircle.setPosition(100, 100);

        // Escalar la textura de cuadAmarillo al tama�o de rcircle despu�s de cargar las texturas
        cuadAmarillo.setScale(0.22, 0.22);
        //cuadAmarillo.setScale(rcircleTexture.getSize().x / cuadAmarilloTexture.getSize().x, rcircleTexture.getSize().y / cuadAmarilloTexture.getSize().y);
        //NOTA: con el codigo de arriba no se mostraba el "cuadAmarillo".


        currentSprite = &cuadAmarillo;

    }


    void run() {
        while (isOpen()) {
            Event event;
            while (pollEvent(event)) {
                if (event.type == Event::Closed) {
                    close();
                }
            }

            handleInput();
            clear();
            draw(*currentSprite);
            display();
        }
    }

private:

    Texture cuadAmarilloTexture;
    Sprite cuadAmarillo;

    Texture rcircleTexture;
    Sprite rcircle;

    Sprite* currentSprite;

    //Escalar tama�os


    void handleInput() {
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
            currentSprite->move(0, -1);
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
            currentSprite->move(0, 1);
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
            currentSprite->move(-1, 0);
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
            currentSprite->move(1, 0);
        }

        // Restringir el movimiento para que las figuras no salgan de la ventana
       Vector2f position = currentSprite->getPosition();
        position.x = std::max(0.0f, std::min(position.x, static_cast<float>(getSize().x - currentSprite->getGlobalBounds().width)));
        position.y = std::max(0.0f, std::min(position.y, static_cast<float>(getSize().y - currentSprite->getGlobalBounds().height)));
        currentSprite->setPosition(position);

        if (Keyboard::isKeyPressed(Keyboard::Space)) {
            if (currentSprite == &cuadAmarillo) {
                currentSprite = &rcircle;
            }
            else {
                currentSprite = &cuadAmarillo;
            }
        }
    }

};

int main() {
    Game game;
    game.run();
    return 0;
}


#include<SFML/Graphics.hpp>
#include<SFML/Window.hpp>

using namespace sf;

Sprite crosshair;
Texture cross_text;

int main(){

	cross_text.loadFromFile("crosshair.png");
	crosshair.setTexture(cross_text);

	RenderWindow App(VideoMode(800, 600, 32), "Ventana fea");

	crosshair.setPosition(350, 225);
	while (App.isOpen()) {
		Event evt;
		while (App.pollEvent(evt)) {
			switch (evt.type) {
			case Event::Closed:
				App.close();
				break;
			}
		}
		App.clear(Color::White);
		App.draw(crosshair);
		App.display();
	}
	return 0;
}
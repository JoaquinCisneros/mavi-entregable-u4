#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

int main() {
    RenderWindow App(VideoMode(800, 600, 32), "Dibujar C�rculos");
    App.setFramerateLimit(60);

    Texture redCircle_t;
    redCircle_t.loadFromFile("rcircle.png");

    Texture blueCircle_t;
    blueCircle_t.loadFromFile("rcircleb.png");

    App.clear();

    while (App.isOpen()) {
        Event evt;
        while (App.pollEvent(evt)) {
            switch (evt.type) {
            case Event::Closed:
                App.close();
                break;

            case Event::MouseButtonPressed:
                if (evt.mouseButton.button == Mouse::Left) {
                    // Crear un c�rculo rojo con el sprite y la textura correspondiente
                    Sprite redCircle(redCircle_t);
                    redCircle.setPosition(evt.mouseButton.x - 30, evt.mouseButton.y - 30);
                    App.draw(redCircle);
                }
                else if (evt.mouseButton.button == Mouse::Right) {
                    // Crear un c�rculo azul con el sprite y la textura correspondiente
                    Sprite blueCircle(blueCircle_t);
                    blueCircle.setPosition(evt.mouseButton.x - 30, evt.mouseButton.y - 30);
                    App.draw(blueCircle);
                }
                break;
            }
        }

        App.display();
    }

    return 0;
}


